pref("extensions.make-it-red.intensity", 100);
pref("extensions.better-copy.format", '> "${text}"\n– **Page ${page}**, *${creators} (${year})*\n${tags}');
